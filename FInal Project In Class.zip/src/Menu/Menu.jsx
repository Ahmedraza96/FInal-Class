import React from 'react';

import { Link } from 'react-router-dom';

class Menu extends React.Component {
    render() {
        return (
            <div>

                <span><Link to="">Home</Link></span>;
                <span><Link to="About">About</Link></span>;
                <span><Link to="Contact">Contact</Link></span>;
                <span><Link to="Login">Login</Link></span>;
                
                
            </div>
        );
    }

}

export default Menu;
