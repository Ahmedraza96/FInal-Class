import React from 'react';
import './style.css'
// import img from './images/room 2.jpg'


class Features extends React.Component {
    render() {
        return (
            <div id="features-wrapper">
                <div className="container">
                <br></br><br></br>
                <div className="row">
                        
                        <div className="col-4 col-12-medium">

                            {/* <!-- Box --> */}
                            <section className="box feature">
                                <a href="#" className="image featured"><img src={require('./images/room 3.jpg')} alt="" /></a>
                                <div className="inner">
                                    <header>
                                        <h2>President Hotel</h2>
                                        <p>Bur Dubai, Dubai, 6 km from center</p>
                                    </header>
                                    <p>Located in Karama, in the center of Dubai, President Hotel offers modern rooms and free Wi-Fi in public areas. It features 2 restaurants and a 24-hour coffee shop.</p>
                                </div>
                            </section>

                        </div>
                        <div className="col-4 col-12-medium">

                            {/* <!-- Box --> */}
                            <section className="box feature">
                                <a href="#" className="image featured"><img src={require('./images/Ho-Sen-Hotel-Vip-Room.jpg')} alt="" /></a>
                                <div className="inner">
                                    <header>
                                        <h2>Vida Downtown</h2>
                                        <p>Downtown Dubai, 650 km center</p>
                                    </header>
                                    <p>Vida Downtown is boutique hotel ideal for business travelers. It features a business center, along with an outdoor pool and gym.<br></br><br></br></p>
                                </div>
                            </section>

                        </div>
                        <div className="col-4 col-12-medium">

                            {/* <!-- Box --> */}
                            <section className="box feature">
                                <a href="#" className="image featured"><img src={require('./images/6u7b2128_29_30_tonemapped(1).jpg')} alt="" /></a>
                                <div className="inner">
                                    <header>
                                        <h2>Mövenpick Hotel Bangkok</h2>
                                        <p>Wattana, Bangkok, 5 km from center</p>
                                    </header>
                                    <p>Easy reach of various businesses and shopping centers like Terminal 21 and EmQuartier Shopping Mall.<br></br><br></br> </p>
                                </div>
                            </section>

                        </div>
                    </div>
                </div>
            </div>
        )
    };
}

export default Features;
