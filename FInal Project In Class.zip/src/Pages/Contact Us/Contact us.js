import React, { Component } from "react";
// import './Style.css';

//Custom Component
import Footer from '../../Components/Footer/Footer'


class Contact extends React.Component {
    render() {
        return (
            <div className="Main">

                <h1>Contact Us</h1>
                <p>u can contact us for detail of our different packages.</p>
                <p>Contact info</p>
                <p>Phone: +92213-4551570-1, +923218299933</p>
                <p>Email us: info@princetravelsandtour.com</p>
                <p>Address: Bungalow No 161-A PECHS Block 3 Sir Syed Road Karachi</p>

            </div>
        );
    }
}

export default Contact;