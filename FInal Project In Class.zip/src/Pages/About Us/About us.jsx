import React, { Component } from "react";
import './Style.css';

import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer'

class About extends React.Component {
    render() {
        return (
            <div id="">
                
            <div className="Main">
                <h1>About Us</h1>
                <p>Established in 1996 in Pakistan, Taiba Aviation has grown from a small Dutch startup to one of the largest travel e-commerce companies in the world. Taiba Aviation now employs more than 17,000 employees in 198 offices, in 55 countries worldwide.</p>
                <p>With a mission to make it easier for everyone to experience the world, Taiba Aviation invests in digital technology that helps take the friction out of travel. At Taiba Aviation, we connect travellers with the world’s largest selection of incredible places to stay, including everything from apartments, vacation homes, and family-run B&Bs to 5-star luxury resorts, tree houses and even igloos. The Taiba Aviation website and mobile apps are available in over 40 languages, offer 28,961,156 total reported listings, and cover 154,889 destinations in 227 countries and territories worldwide.</p>
                <p>Every day, more than 1,550,000 room nights are reserved on our platform. So whether traveling for business or leisure, customers can instantly book their ideal accommodations quickly and easily with Taiba Aviation – without booking fees and backed by our promise to price match. Through our Customer Experience Team, customers can reach Taiba Aviation 24/7 for assistance and support in over 40 languages, anytime day or night.</p>
            </div>
                <Footer />
            </div >
        );
    }
}

export default About;
