//Basic Component
import React from 'react';

//Router
import { BrowserRouter as Router, Route } from 'react-router-dom';

//Custom CSS
import './App.css';

//Custom Component
import Header from './Components/Header/Header.js';
import Login from './Pages/Login/Login';
import About from './Pages/About Us/About us';
import Contact from './Pages/Contact Us/Contact us';
import Menu from './Menu/Menu';

// import LoginSide from './Components/Login/Login side';

class App extends React.Component {
  render() {
    return (
      <div className="App">
        <Router>
          {/* <Menu /> */}

          <switch>

            <Route path='/' exact component={Header} />
            <Route path='/login' component={Login} />
            <Route path='/About' component={About} />
            <Route path='/Contact' component={Contact} />


          </switch>

        </Router>
      </div>
    )
  };
}
export default App;
